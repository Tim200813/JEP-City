import tkinter as tk
from tkinter import ttk, messagebox

def show_info_popup(event=None):
    messagebox.showinfo(
        "Info",
        "💡 Dieses Programm wird gerade aktualisiert.\n\nBitte später erneut versuchen.\n\nTastenkürzel entdeckt: Strg+I"
    )

def create_maintenance_window():
    # Fenster erstellen
    root = tk.Tk()
    root.title("Wartungsmodus")
    root.geometry("400x250")
    root.configure(bg="#1e1e2f")

    # Stil setzen
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("TLabel", foreground="white", background="#1e1e2f", font=("Helvetica", 14))
    style.configure("Title.TLabel", font=("Helvetica", 18, "bold"), foreground="#f7c948")

    # Titel-Label
    title_label = ttk.Label(root, text="🛠️ Wartungsarbeiten", style="Title.TLabel")
    title_label.pack(pady=(30, 10))

    # Text-Label
    text_label = ttk.Label(root, text="Das Programm befindet sich\nnoch in Wartungsarbeiten.", justify="center")
    text_label.pack(pady=(10, 30))

    # Ladeanimation
    progress = ttk.Progressbar(root, mode='indeterminate', length=200)
    progress.pack(pady=10)
    progress.start(10)

    # Tastenkombination (Ctrl+I) für Info-Popup
    root.bind("<Control-i>", show_info_popup)

    # Hinweis auf Shortcut (klein und dezent)
    shortcut_label = ttk.Label(root, text="(Tipp: Drücke Strg+I)", font=("Helvetica", 10))
    shortcut_label.pack(side="bottom", pady=5)

    # Fenster anzeigen
    root.mainloop()

create_maintenance_window()
