# bot_uploader.py
import discord
from discord.ext import commands

TOKEN = "MTM3Nzk3NzMxMjgxNzE4ODk0NQ.GQX266.cX-psrhJqYM5CJzJ2UEqhZYzixkMjt6rVmWpm4"
CHANNEL_ID = 1274486181903732749  # ID deines Zielkanals

# ⬅️ Intents festlegen
intents = discord.Intents.default()
intents.message_content = True  # Nur nötig, wenn du Nachrichten lesen willst

# ⬅️ Bot mit Intents erstellen
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"✅ Bot ist online als {bot.user}")

async def send_file_embed(file_path, section):
    channel = bot.get_channel(CHANNEL_ID)
    embed = discord.Embed(
        title=f"{section} – Neue Datei",
        description="Hier ist die aktuelle Datei.",
        color=0x2ecc71
    )
    file = discord.File(file_path)
    embed.set_footer(text="Automatischer Upload")
    await channel.send(embed=embed, file=file)

bot.run(TOKEN)  # ← Aktiviere dies, wenn du starten willst