import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from PIL import Image, ImageTk
import threading
import asyncio
import json
import os
import discord
from discord.ext import commands

# --- Discord Bot Setup ---
TOKEN = "MTM3Nzk3NzMxMjgxNzE4ODk0NQ.GQX266.cX-psrhJqYM5CJzJ2UEqhZYzixkMjt6rVmWpm4"
CHANNEL_ID = 1274486181903732749  # ID deines Zielkanals

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"Bot online als {bot.user}")

async def send_file_embed(file_path, section, username=None, description=None):
    channel = bot.get_channel(CHANNEL_ID)
    if channel is None:
        print("Kanal nicht gefunden!")
        return

    if section == "Stadt" and username:
        title = f"Neue Version von {username} hochgeladen"
    else:
        title = f"{section} – Neue Datei"

    if description:
        description = f"🆕 **Neu:**\n{description}"
    else:
        description = "Hier ist die aktuelle Datei."


    embed = discord.Embed(title=title, description=description, color=0x2ecc71)
    file = discord.File(file_path)
    embed.set_footer(text="Automatischer Upload")
    await channel.send(embed=embed)
    await channel.send(file=file)



# Bot im eigenen Thread starten
def start_bot():
    asyncio.run(bot.start(TOKEN))

bot_thread = threading.Thread(target=start_bot, daemon=True)
bot_thread.start()

# --- Tkinter GUI Setup ---
root = tk.Tk()
root.title("Uploader GUI")
root.geometry("400x500")

# 1. Team Übersicht anzeigen (aus JSON)
def show_team():
    # Lade team.json
    try:
        with open("team.json", "r", encoding="utf-8") as f:
            team_info = json.load(f)
    except Exception as e:
        messagebox.showerror("Fehler", f"Konnte team.json nicht laden:\n{e}")
        return

    win = tk.Toplevel(root)
    win.title("Team Übersicht")
    win.geometry("300x400")

    canvas = tk.Canvas(win)
    scrollbar = tk.Scrollbar(win, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    # Stylishe Farben für Rollen
    colors = {
        "Bürgermeister": "#FFD700",  # Gold
        "IT-Typen": "#3498db",       # Blau
        "Arbeiter": "#2ecc71",       # Grün
        "Bewohner": "#95a5a6"        # Grau
    }

    for role, members in team_info.items():
        frame = tk.LabelFrame(scrollable_frame, text=role, padx=10, pady=10,
                              fg="white", bg=colors.get(role, "#34495e"),
                              font=("Arial", 12, "bold"))
        frame.pack(fill="x", padx=10, pady=5)

        # Set Frame Hintergrund auch
        frame.config(bg=colors.get(role, "#34495e"))

        for person in members:
            lbl = tk.Label(frame, text=person, bg=colors.get(role, "#34495e"),
                           fg="white", font=("Arial", 10))
            lbl.pack(anchor="w")

# 2. Bild aus Image-Ordner anzeigen (Netz)
def show_image():
    img_path = os.path.join("Image", "netzbild.jpg")
    if not os.path.isfile(img_path):
        messagebox.showerror("Fehler", f"Bild nicht gefunden:\n{img_path}")
        return

    win = tk.Toplevel(root)
    win.title("Netz Bild")

    # Bild laden und skalieren
    img = Image.open(img_path)
    img.thumbnail((380, 380))
    photo = ImageTk.PhotoImage(img)

    lbl_img = tk.Label(win, image=photo)
    lbl_img.image = photo  # Referenz halten
    lbl_img.pack(padx=10, pady=10)

# 3. Stadt - Datei auswählen + Name eingeben + Upload
def upload_stadt():
    file_path = filedialog.askopenfilename(title="Datei für Stadt auswählen")
    if not file_path:
        return

    username = simpledialog.askstring("Name eingeben", "Bitte gib deinen Namen ein:")
    if not username:
        messagebox.showwarning("Abgebrochen", "Kein Name eingegeben, Upload abgebrochen.")
        return

    description = simpledialog.askstring("Beschreibung (optional)", "Was ist neu in dieser Datei?")
    if not description:
        description = f"Hier ist die aktuelle Datei von {username}."

    # Discord-Upload starten
    future = asyncio.run_coroutine_threadsafe(
        send_file_embed(file_path, "Stadt", username=username, description=description),
        bot.loop
    )
    try:
        future.result()
        messagebox.showinfo("Erfolg", f"Datei von {username} wurde hochgeladen!")
    except Exception as e:
        messagebox.showerror("Fehler", f"Upload fehlgeschlagen:\n{e}")

def check_for_update():
    # Hier ein fiktiver Versionsvergleich (in der Realität von Datei oder URL)
    aktuelle_version = "1.0.0"

    try:
        with open("version.txt", "r", encoding="utf-8") as f:
            neueste_version = f.read().strip()
    except FileNotFoundError:
        neueste_version = aktuelle_version

    if neueste_version > aktuelle_version:
        if messagebox.askyesno("Update verfügbar", f"Neue Version {neueste_version} verfügbar. Jetzt aktualisieren?"):
            # Hier könntest du z. B. eine neue Datei kopieren, entpacken, oder aus dem Internet laden
            messagebox.showinfo("Update", "Update erfolgreich installiert!")  # Nur Platzhalter
    else:
        messagebox.showinfo("Up to Date", "Du hast bereits die neueste Version.")



# Haupt Upload-Funktion, die für Team, Netz, Stadt entscheidet
def upload(section):
    if section == "Team":
        show_team()
    elif section == "Netz":
        show_image()
    elif section == "Stadt":
        upload_stadt()
    else:
        messagebox.showinfo("Info", f"Funktion für {section} noch nicht implementiert.")

# Buttons erzeugen
for sec in ["Team", "Netz", "Arbeit hochladen"]:
    btn = tk.Button(root, text=sec, width=20, height=2, command=lambda s=sec: upload(s))
    btn.pack(pady=15)
btn_update = tk.Button(root, text="🔄 Update prüfen", width=20, height=2, command=lambda: check_for_update())
btn_update.pack(pady=15)


root.mainloop()
